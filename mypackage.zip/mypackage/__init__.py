print("This is from mypackage")

my_name = "mypackage"

__all__ = ["a","c"]
