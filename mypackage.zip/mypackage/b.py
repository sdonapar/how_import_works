#!/usr/bin/env python

from . import a,c

name = "b"

def func_b():
    print("This is from function b")
