#!/usr/bin/env python

my_module_name = "mypackage:subpkg1:module3"

def my_func():
    print("This is from mypackage - subpkg1 - module3")
