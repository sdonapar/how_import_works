print("This is from subpkg1")

__all__ = ["sp1_module1","sp1_module2"]
