#!/usr/bin/env python

name = "c"

print("this is from module c")

def func_c():
    print("This is from function c")
