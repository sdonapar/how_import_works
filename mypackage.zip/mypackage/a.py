#!/usr/bin/env python

name = "a"
print("This is from module a")

def func_a():
    print("This is from function a")
